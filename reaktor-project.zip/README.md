# Reaktor

AI content repurposing tool — turn one video, podcast, or blog post into
ready-to-post drafts for X, LinkedIn, Instagram, YouTube Shorts, and your blog.

## Run locally

```bash
npm install
npm run dev
```

Open the printed localhost URL in your browser.

## Build for production

```bash
npm run build
```

This creates a `dist/` folder ready to deploy.

## Deploy (free, no server needed)

1. Push this repo to GitHub.
2. Go to [vercel.com](https://vercel.com) → "Add New Project" → import this
   GitHub repo.
3. Vercel auto-detects Vite and deploys it. You'll get a live URL like
   `reaktor.vercel.app`.

## Install as an app (PWA)

Once deployed, open the live URL on your phone or desktop in Chrome/Edge.
You'll see an **Install** option in the address bar (desktop) or an
**"Add to Home Screen"** prompt (mobile). This installs Reaktor as a
standalone app — no app store needed.
